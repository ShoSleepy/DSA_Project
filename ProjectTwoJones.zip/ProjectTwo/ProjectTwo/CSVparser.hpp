#ifndef CSVPARSER_HPP
#define CSVPARSER_HPP

#include <iostream>
#include <vector>
#include <string>
#include <fstream>
#include <sstream>

class CSVParser {
public:
    static std::vector<std::vector<std::string>> parseCSV(const std::string& fileName);
};

#endif // CSVPARSER_HPP