// Name: Brandon Jones
// Date: 10/19/2024

#include <iostream>
#include <vector>
#include <algorithm>
#include "CSVparser.hpp"

using namespace std;

// Struct for course information
struct Course {
    string courseNumber;
    string title;
    vector<string> prerequisites;

    // Constructor for initializing course data
    Course(string number, string name) : courseNumber(number), title(name) {}
};

// Function to load courses from a CSV file using CSVParser
vector<Course> loadCourses(const string& fileName) {
    vector<Course> courses;
    vector<vector<string>> data = CSVParser::parseCSV(fileName);

    for (const auto& row : data) {
        if (row.size() < 2) {
            cout << "Error: Invalid line format." << endl;
            continue;
        }

        string courseNumber = row[0];
        string title = row[1];
        vector<string> prerequisites;

        for (size_t i = 2; i < row.size(); ++i) {
            prerequisites.push_back(row[i]);
        }

        courses.emplace_back(courseNumber, title);
        courses.back().prerequisites = prerequisites;
    }

    return courses;
}

// Function to sort and print courses in alphanumeric order
void printCourses(vector<Course>& courses) {
    sort(courses.begin(), courses.end(), [](Course a, Course b) {
        return a.courseNumber < b.courseNumber;
        });

    for (const auto& course : courses) {
        cout << course.courseNumber << ": " << course.title << endl;
    }
}

// Function to search for a course in the vector
void searchCourse(const vector<Course>& courses, const string& courseNumber) {
    for (const auto& course : courses) {
        if (course.courseNumber == courseNumber) {
            cout << "Course: " << course.courseNumber << " - " << course.title << endl;
            if (!course.prerequisites.empty()) {
                cout << "Prerequisites: ";
                for (const auto& prereq : course.prerequisites) {
                    cout << prereq << " ";
                }
                cout << endl;
            }
            else {
                cout << "No prerequisites." << endl;
            }
            return;
        }
    }
    cout << "Error: Course not found." << endl;
}

// Main menu function
void mainMenu() {
    vector<Course> courses;

    while (true) {
        cout << "1. Load Courses" << endl;
        cout << "2. Print All Courses (Alphanumeric Order)" << endl;
        cout << "3. Search Course" << endl;
        cout << "9. Exit" << endl;

        int choice;
        cout << "Enter choice: ";
        cin >> choice;

        if (choice == 1) {
            string fileName;
            cout << "Enter the file name (e.g., 'CS300_ABCU_Advising_Program_Input.csv'): ";
            cin >> fileName;

            // Load courses using the CSV parser
            courses = loadCourses(fileName);

            if (courses.empty()) {
                cout << "No courses loaded." << endl;
            }
            else {
                cout << "Courses loaded successfully." << endl;
            }
        }
        else if (choice == 2) {
            if (courses.empty()) {
                cout << "No courses to display. Please load the data first." << endl;
            }
            else {
                printCourses(courses);
            }
        }
        else if (choice == 3) {
            if (courses.empty()) {
                cout << "No courses to search. Please load the data first." << endl;
            }
            else {
                string courseNumber;
                cout << "Enter course number: ";
                cin >> courseNumber;
                searchCourse(courses, courseNumber);
            }
        }
        else if (choice == 9) {
            cout << "Exiting..." << endl;
            break;
        }
        else {
            cout << "Invalid choice. Please try again." << endl;
        }
    }
}

int main() {
    mainMenu();
    return 0;
}