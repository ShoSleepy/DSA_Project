#include "CSVparser.hpp"

// Function to parse CSV file and return data as a vector of vectors
std::vector<std::vector<std::string>> CSVParser::parseCSV(const std::string& fileName) {
    std::vector<std::vector<std::string>> data;
    std::ifstream file(fileName);

    // Debug: Display the file name being attempted
    std::cout << "Attempting to open file: " << fileName << std::endl;

    if (!file.is_open()) {
        std::cerr << "Error: Cannot open the file '" << fileName << "'." << std::endl;
        std::cerr << "Ensure the file is in the correct directory or provide the absolute path." << std::endl;
        return data;
    }

    std::string line;
    while (getline(file, line)) {
        std::stringstream ss(line);
        std::vector<std::string> tokens;
        std::string token;

        // Split the line by comma
        while (getline(ss, token, ',')) {
            tokens.push_back(token);
        }

        // Add tokens to the data vector if not empty
        if (!tokens.empty()) {
            data.push_back(tokens);
        }
    }

    file.close();
    return data;
}